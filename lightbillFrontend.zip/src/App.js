import { useEffect, useRef, lazy, Suspense } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Route, Routes, Navigate, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Button from '@mui/material/Button';

import Sidebar from './Sidebar';
import { fetchBills } from './store/actions/billActions';
import { upComingDueBills } from './utils/DueBillHelper';

// ─── Lazy Loaded Pages ────────────────────────────────────────────────────────
// प्रत्येक page component lazy load होईल — फक्त त्या route वर गेल्यावर download होईल
const User                    = lazy(() => import('./pages/User'));
const Home                    = lazy(() => import('./pages/Home'));
const Rolemaster               = lazy(() => import('./pages/Rolemaster'));
const Register                = lazy(() => import('./pages/auth/Register'));
const Login                   = lazy(() => import('./pages/auth/Login'));
const ConsumerBill             = lazy(() => import('./pages/ConsumerBill'));
const Profile                 = lazy(() => import('./pages/auth/Profile'));
const ApprovedStatusRecord     = lazy(() => import('./pages/ApprovedStatusRecord'));
const PaidBills                = lazy(() => import('./pages/PaidBills'));
const PartialPaidBills         = lazy(() => import('./pages/PartialPaidBills'));
const MassApprovalsBills       = lazy(() => import('./pages/MassApprovalsBills'));
const UsersUpcomingDueBills    = lazy(() => import('./pages/UsersUpcomingDueBills'));
const ConsumerBillDetails      = lazy(() => import('./pages/ConsumerBillDetails'));
// const MeterComponent           = lazy(() => import('./pages/MeterComponents'));
// const TarriffMaster            = lazy(() => import('./pages/TarriffMaster'));
const Overduebills             = lazy(() => import('./pages/Overduebills'));
const ConsumerComponent        = lazy(() => import('./pages/ConsumerComponents'));
const Formonetwentynew         = lazy(() => import('./pages/Formonetwentynew'));
const BillingAnomaly           = lazy(() => import('./pages/BillingAnomaly'));
const PenaltyReport            = lazy(() => import('./pages/PenaltyReport')); // NEW (7-Oct-2026)
const RegionalEnergyExpenditure = lazy(() => import('./pages/RegionalEnergyExpenditure'));

// ─── Page Loading Fallback ────────────────────────────────────────────────────
// Route switch होताना हा spinner दिसेल
function PageLoader() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '60vh',
      flexDirection: 'column',
      gap: 12,
      fontFamily: 'sans-serif',
      color: '#6b7280',
    }}>
      <div style={{
        width: 36,
        height: 36,
        border: '4px solid #e5e7eb',
        borderTopColor: '#0d2136',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <span style={{ fontSize: 13 }}>Loading…</span>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
const App = () => {
  const dispatch   = useDispatch();
  const navigate   = useNavigate();
  const user       = useSelector((state) => state.auth.user);
  const { bills }  = useSelector((state) => state.bills);
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);
  const toastIdRef = useRef(null);

  const dueAlertrows = upComingDueBills(bills, user);
  const dueAlertCount = dueAlertrows.length;

  // ── Bills fetch ──────────────────────────────────────────────────────────────
  // OLD (3-Oct-2026 पर्यंत): login page वर सुद्धा 10,000 bills download होत होते
  // useEffect(() => {
  //   dispatch(fetchBills());
  // }, [dispatch]);

  // NEW (3-Oct-2026): login झाल्यावरच bills fetch (due-bill reminder साठी लागतात)
  useEffect(() => {
    if (isAuthenticated) {
      dispatch(fetchBills());
    }
  }, [dispatch, isAuthenticated]);

  // ── Auth restore from localStorage ──────────────────────────────────────────
  useEffect(() => {
    const storedData = localStorage.getItem('resdata');
    if (storedData) {
      const resData = JSON.parse(storedData);
      if (resData.token) {
        dispatch({ type: 'LOGIN_SUCCESS', payload: resData });
        navigate('/');
      }
    }
  }, [dispatch]);

  // ── Due-bill toast reminder ──────────────────────────────────────────────────
  useEffect(() => {
    let timer;

    const showToast = () => {
      if (dueAlertCount === 0 || !isAuthenticated || toastIdRef.current) return;

      const isSmallScreen  = window.innerWidth <= 599;
      const isMediumScreen = window.innerWidth >= 600 && window.innerWidth <= 900;

      toastIdRef.current = toast.error(
        `Reminder: You have a total of ${dueAlertCount} pending light bills. Please ensure that you do not cross the due date, as late payments will incur additional charges.`,
        {
          position: 'top-center',
          autoClose: false,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          style: {
            backgroundColor: '#FAFAFA',
            color: '#000',
            width:    isSmallScreen ? '350px' : isMediumScreen ? '599px' : '600px',
            height:   isSmallScreen ? '80px'  : '60px',
            fontSize: isSmallScreen ? '11px'  : '15px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          },
        }
      );
    };

    if (bills.length > 0 && isAuthenticated) {
      timer = setTimeout(showToast, 6000);
      return () => {
        if (timer) clearTimeout(timer);
        if (toastIdRef.current) toast.dismiss(toastIdRef.current);
      };
    }
  }, [bills.length, dueAlertCount, isAuthenticated]);

  // ── Logout ───────────────────────────────────────────────────────────────────
  const handleLogout = () => {
    localStorage.removeItem('resdata');
    dispatch({ type: 'LOGOUT' });
    navigate('/login');
  };

  return (
    <>
      <Sidebar />

      {/*
        Suspense — lazy component load होताना PageLoader दाखवतो.
        Sidebar बाहेर आहे कारण तो lazy नाही — तो नेहमी दिसतो.
      */}
      <Suspense fallback={<PageLoader />}>
        <Routes>
          {isAuthenticated ? (
            <>
              <Route path="/"                              element={<Home />} />
              <Route path="/users"                         element={<User />} />
              <Route path="/consumer-bill-details/:id"     element={<ConsumerBillDetails />} />
              <Route path="/specificconsumerbills"         element={<ConsumerBillDetails />} />
              <Route path="/formonetwentynew"              element={<Formonetwentynew />} />
              <Route path="/rolemaster"                    element={<Rolemaster />} />
              <Route path="/bills"                         element={<ConsumerBill />} />
              {/* <Route path="/tarriffscomponent"             element={<TarriffMaster />} /> */}
              {/* <Route path="/metercomponent"                element={<MeterComponent />} /> */}
              <Route path="/consumercomponent"             element={<ConsumerComponent />} />
              <Route path="/usersupcomingduebills"         element={<UsersUpcomingDueBills />} />
              <Route path="/overduebills"                  element={<Overduebills />} />
              <Route path="/massapprovalsbills"            element={<MassApprovalsBills />} />
              <Route path="/profile"                       element={<Profile />} />
              <Route path="/pendingapprovals"              element={<ApprovedStatusRecord />} />
              <Route path="/billinganomaly"                element={<BillingAnomaly />} />
              <Route path="/penalty"                       element={<PenaltyReport />} /> {/* NEW (7-Oct-2026) */}
              <Route path="/paidbills"                     element={<PaidBills />} />
              <Route path="/partialpaidbills"              element={<PartialPaidBills />} />
              <Route path="/regionalenergyexpenditure"     element={<RegionalEnergyExpenditure />} />
              <Route
                path="/logout"
                element={
                  <Button sx={{ color: '#0d2136' }} onClick={handleLogout}>
                    Logout
                  </Button>
                }
              />
            </>
          ) : (
            <>
              <Route path="/login"    element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="*"         element={<Navigate to="/login" />} />
            </>
          )}
        </Routes>
      </Suspense>
    </>
  );
};

export default App;